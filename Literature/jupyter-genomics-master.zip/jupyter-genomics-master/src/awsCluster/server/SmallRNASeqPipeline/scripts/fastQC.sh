#!/bin/sh

/shared/workspace/software/FastQC/fastqc --noextract $inputFile 
