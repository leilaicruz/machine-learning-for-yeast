#!/bin/sh

fileName=$1

#rm -r $fileName*

