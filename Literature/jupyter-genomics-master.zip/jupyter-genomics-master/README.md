# jupyter-genomics
A collection of Jupyter notebooks authored by the UCSD Center for Computational Biology & Bioinformatics (http://compbio.ucsd.edu). These include methods on utilizing cloud computing resources and analysis of data from next-generation sequencing, systems biology, and microbiome.
